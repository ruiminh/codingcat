import java.sql.*;


public class Main {
    public static Connection connection;

    public static void main(String[] args) {
         Connection connection=null;
         String pass="Rh458715";
         PreparedStatement ps=null;
         PreparedStatement ps1=null;

         try {connection= DriverManager.getConnection("jdbc:mysql://localhost:3306/world","root",pass );

         } catch (SQLException throwables) {
             throwables.printStackTrace();
         }
         try{
             ps=connection.prepareStatement("SELECT * FROM city") ;
             ResultSet rs= ps.executeQuery();
             System.out.println(rs);
         }catch (SQLException e){
             e.printStackTrace();

         }

    }
}

    