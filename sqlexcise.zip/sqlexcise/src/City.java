import java.sql.*;
import java.util.ArrayList;

public class City {
    private PreparedStatement ps1=null;
    ArrayList cityList=new ArrayList();


        try {
        ps1=Main.connection.prepareStatement("SELECT * FROM city WHERE population>5000000") ;
        ResultSet rs1= null;
            rs1 = ps1.executeQuery();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }



    



}
