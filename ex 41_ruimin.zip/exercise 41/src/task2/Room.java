package task2;

public class Room {

    private String walls;
    private int numberOfDoors;
    private int numberOfLamps;
    private int numberOfWindows;

    Room(String walls, int numberOfDoors, int numbersOfLamps, int numbersOfWindows) {
        this.walls=walls;
        this.numberOfDoors=numberOfDoors;
        this.numberOfLamps=numbersOfLamps;
        this.numberOfWindows=numbersOfWindows;

    }

    public String getWalls() {
        return walls;
    }

    public int getNumberOfDoors() {
        return numberOfDoors;
    }

    public int getNumberOfLamps() {
        return numberOfLamps;
    }

    public int getNumberOfWindows() {
        return numberOfWindows;
    }
}
