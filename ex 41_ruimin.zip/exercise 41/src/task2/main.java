package task2;



import java.util.ArrayList;


public class main {
    public static void main(String[] args) {
        Room room1=new Room("red",1,4,2);
        Room room2=new Room("blue",1,2,1);
        Room room3=new Room("grey",2,4,0);

        ArrayList<Room> rooms=new ArrayList<Room>(3);
        rooms.add(room1);
        rooms.add(room2);
        rooms.add(room3);


        Building building =new Building(rooms, 2,6,false);
        int lamp1=rooms.get(0).getNumberOfLamps(); //room1
        int lamp2=rooms.get(1).getNumberOfLamps(); //room2
        int lamp3=rooms.get(2).getNumberOfLamps(); //room3

        System.out.println(lamp1+lamp2+lamp3);

        if(building.getNumberOfFloors()>3)
        {
            System.out.println("This is an odd building.");

        }


    }
}