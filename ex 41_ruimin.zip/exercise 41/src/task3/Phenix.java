package task3;

public class Phenix extends Animal{

    public Phenix(int numberOfLegs) {
        super(numberOfLegs);
    }

    @Override
    public void makeSound() {
        System.out.println("Phenix goes hahaaaa");
    }
}
