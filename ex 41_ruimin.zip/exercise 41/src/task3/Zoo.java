package task3;

import java.util.ArrayList;

public class Zoo {


    ArrayList<Animal> animals=new ArrayList<>(3);

    public void makeAllSound(){
        for(int i =0; i<animals.size();i++){
            animals.get(i).makeSound();
        }
    }

    public void addAnimal(Animal newAnimal){
        animals.add(newAnimal);
    }

    public void printNumberOfLegs(){
        int Legs=0;
        for(int i =0;i<animals.size();i++){
            Legs=Legs+animals.get(i).getNumberOfLegs();
        }
        System.out.println("Total number of legs in my zoo: "+Legs);
    }






}
