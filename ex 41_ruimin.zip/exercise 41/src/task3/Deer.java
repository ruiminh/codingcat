package task3;

public class Deer extends Animal {

    public Deer(int numberOfLegs) {
        super(numberOfLegs);
    }
}
