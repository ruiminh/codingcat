package task3;

public class main {
    public static void main(String[] args) {
        Zoo zoo=new Zoo();
        Animal deer =new Deer(4);
        Animal phenix= new Phenix(2);
        Animal worm= new Worm(100);

        zoo.addAnimal(deer);
        zoo.addAnimal(phenix);
        zoo.addAnimal(worm);

        zoo.makeAllSound();
        zoo.printNumberOfLegs();
    }
}
