package task3;

public class Worm extends Animal{

    public Worm(int numberOfLegs) {
        super(numberOfLegs);
    }

    @Override
    public void makeSound() {
        System.out.println("worm goes Shhhh");
    }
}
