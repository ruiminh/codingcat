package task1;

public class Driver {

    private String name;
    private int age;

    Driver(String name, int age){
        this.name=name;
        this.age=age;

    }

    public String getDriverName() {
        return name;
    }

    public void setDriverName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "is driven by" +name;
    }
}
