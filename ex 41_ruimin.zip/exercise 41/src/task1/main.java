package task1;

public class main {

    public static void main(String[] args) {
        Driver driver1=new Driver("Ruimin",100);
        Car car=new Car("WW","Audi",2017,"Sports");

        car.setDriver(driver1);
        System.out.println(car.toString());
        System.out.println(driver1.toString());

        Car car2=new Car("Tesla","m3",2020,"el");
        car2.setDriver(driver1);
        System.out.println(car2.toString());


    }



}
